# 🥑📱 GROCERY SHOP APP x FLUTTER

Watch tutorial here: https://youtu.be/uSljGJGSl6w

![53AC0750-FB81-4C11-9349-448E7FC4717E](https://user-images.githubusercontent.com/29016489/202695738-b37d8ffe-a2c7-41fb-9719-b032bb1ab8c4.JPG)
